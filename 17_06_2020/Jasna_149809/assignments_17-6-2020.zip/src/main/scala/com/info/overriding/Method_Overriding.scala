package com.info.overriding

class Vehicle{
  def run(): Unit =
  {
    println("Vehicle is running")
  }
}
class Bike extends Vehicle {
  override def run(): Unit = {
    println("Bike is running...")
  }
}
object Method_Overriding {
  def main(args: Array[String]): Unit = {
    var obj=new Bike()
    obj.run()
  }


}
