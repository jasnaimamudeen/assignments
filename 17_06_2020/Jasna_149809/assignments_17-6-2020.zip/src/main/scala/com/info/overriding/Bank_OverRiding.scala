package com.info.overriding

class Bank{
  def getRateofInterest()={
  0
  }
}
class SBI extends Bank {
  override def getRateofInterest() = {
    7
  }
}
class Federal extends Bank {
  override def getRateofInterest() = {
    10
  }
}
  class Axis extends Bank{
    override def getRateofInterest()={
      super.getRateofInterest()
      12
    }

}
object Bank_OverRiding {
  def main(args: Array[String]){
    var sbi= new SBI();
    var federal= new Federal();
    var axis=new Axis();
    println("SBI Rate of Interest"+sbi.getRateofInterest())
    println("Federal Rate of Interest"+federal.getRateofInterest())
    println("Axis Rate of Interest"+axis.getRateofInterest())


  }


}
