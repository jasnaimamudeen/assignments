package com.info.overriding
class  Account{

}

object InSufficientFundException {

}
