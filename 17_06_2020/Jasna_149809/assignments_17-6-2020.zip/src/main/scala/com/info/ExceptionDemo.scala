package com.info

object ExceptionDemo {
  def main(args: Array[String]): Unit = {
    try{
      var x=Integer.parseInt("456")
      var y=0

      var quotient=x/y;
      println("Quotient":+quotient)
    }
    catch{
      case ae:ArithmeticException=>{
        println("Second number should not be zero")
      }
      case nfe:NumberFormatException=>{
        println("Input must be Numerical String")
      }
    }
  }

}
