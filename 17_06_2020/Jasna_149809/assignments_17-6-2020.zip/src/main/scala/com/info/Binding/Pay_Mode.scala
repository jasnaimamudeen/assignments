package com.info.Binding

class Payment{
  def paybill(): Unit ={
    println("Payment Mode")
  }
  class CreditCard extends Payment{
    override def paybill(): Unit ={
      println("Payment using CreditCard")
    }
  }
  class DebitCard extends Payment{
    override def paybill(): Unit ={
      println("Payment using DebitCard")
    }
  }
  class Cheque extends Payment{
    override def paybill(): Unit ={
      println("Payment using Cheque")
    }
  }
}
object Pay_Mode {
  def main(args: Array[String]): Unit = {




  }

}
