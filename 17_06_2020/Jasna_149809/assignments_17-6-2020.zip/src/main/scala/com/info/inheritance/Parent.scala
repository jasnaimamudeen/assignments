package com.info.inheritance

class Parent {
  var SNo:Int =1
  var Name:String = "Adam"
  var Marks:String = "485"

}
class Child1 extends Parent {
  var Rank: Int = 12
}

  class Child2 extends Child1 {
    var Height:Int =164
    def details(): Unit =
    {
      println("SNo"+SNo)
      println("Sname:"+Name)
      println("Marks:"+Marks)
      println("Rank:"+Rank)
      println("Height"+Height)
    }



}
