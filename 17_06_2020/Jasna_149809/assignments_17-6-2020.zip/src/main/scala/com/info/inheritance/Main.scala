package com.info.inheritance

object Main {
  def main(args: Array[String]) {
    val obj=new Child2
    obj.details()

  }

}
